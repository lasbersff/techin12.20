const div1 = document.getElementById('div1');

div1.addEventListener('dragover', (event) => {
    event.preventDefault(); 
});

div1.addEventListener('drop', (event) => {
    event.preventDefault();
    const id = event.dataTransfer.getData('text');
    const draggableElement = document.getElementById(id);
    const dropzone = event.target;
    dropzone.appendChild(draggableElement);
});

const images = document.querySelectorAll('img');
images.forEach((img, index) => {
    img.id = `img-${index}`;
    img.addEventListener('dragstart', (event) => {
        event.dataTransfer.setData('text', event.target.id);
    });
});
